package io.annchain.hackathon.sdk.model;

import lombok.Data;

@Data
public class NewTxResp {
    String hash;
    String err;
}
