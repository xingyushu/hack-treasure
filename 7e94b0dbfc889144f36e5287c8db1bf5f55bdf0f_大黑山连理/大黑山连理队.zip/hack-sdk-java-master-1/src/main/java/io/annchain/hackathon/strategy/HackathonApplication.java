package io.annchain.hackathon.strategy;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import io.annchain.hackathon.sdk.OgSolver;
import io.annchain.hackathon.sdk.model.*;
import org.apache.commons.codec.DecoderException;
import org.omg.CORBA.INTERNAL;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;

import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

@SpringBootApplication(scanBasePackages = "io.annchain.hackathon")
public class HackathonApplication implements CommandLineRunner {

    private static Logger logger = LoggerFactory.getLogger(HackathonApplication.class);
    private static final int TXTYPE_SEQUENCER = 1;
    private static final int TXTYPE_TX = 0;
    private static final String address = "7e94b0dbfc889144f36e5287c8db1bf5f55bdf0f";
    private static final String addressHex = "0x7e94b0dbfc889144f36e5287c8db1bf5f55bdf0f";
    private static int guarantee = 100;
    private static List<TransactionResp> list = new ArrayList<TransactionResp>();
    private static List<TransactionResp> list2 = new ArrayList<TransactionResp>();
    private static List<TransactionResp> listMy = new ArrayList<TransactionResp>();
    private static List<TransactionResp> listElse = new ArrayList<TransactionResp>();
    private static TransactionResp transaction = null;
    private static SequencerResp sequencerResp = null;
    private static boolean flag = false;
    private static boolean flag2 = false;
    private static boolean flag3 = false;
    private static Config config = Config.getConfig();
    private static int count = config.getCount();
    private static int num = config.getNum();
    private static int total = 0;
    private static int k = config.getGuarantee5();
    private static Date date = null;
    @Autowired
    OgSolver ogSolver;

    public static void main(String[] args) {
        SpringApplication.run(HackathonApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        // ogSolver.queryTxsByAddress(address);
    }

    @KafkaListener(topics = "${app.topic}", groupId = "${api.token}")
    public void listen(@Payload String json) throws Exception {
        // logger.info(json);
        JSONObject obj = JSON.parseObject(json);
        switch (obj.getIntValue("type")) {
            case TXTYPE_SEQUENCER:
                SequencerResp seq = obj.getObject("data", SequencerResp.class);
                handleSequencer(seq);
                break;
            case TXTYPE_TX:
                TransactionResp tx = obj.getObject("data", TransactionResp.class);
                handleTx(tx);
                break;
            default:
                break;
        }
    }

    private void handleTx(TransactionResp tx) {
        // if(new Integer(tx.getGuarantee())>=config.getGuarantee3()){
        //     transaction=tx;
        //     String hash=listMy.get(listMy.size() - 1).getHash();
        //     listMy.clear();
        //     sendTx(new String[]{hash, tx.getHash()}, config.getGuarantee4());
        //     flag3 = true;
        //     return;
        // }
        // if(flag3){
        //     if(k>0){
        //         if (tx.getFrom().equals(addressHex)) {
        //             listMy.add(tx);
        //             sendTx(new String[]{listMy.get(listMy.size() - 1).getHash(), transaction.getHash()}, config.getTime5()-config.getGuarantee6());
        //             k--;
        //         }
        //     }
        //     return;
        // }
        if(total>num){
            return;
        }
        if (flag) {
            date = new Date();
            flag = false;
        }
        if (tx.getFrom().equals(addressHex)) {
            // logger.info("received tx: " + tx.getHash());
            listMy.add(tx);
        } else {
            listElse.sort(new ComparatorUser());
            if (listElse.size() == count) {
                Integer integer1 = new Integer(listElse.get(listElse.size() - 1).getGuarantee());
                Integer integer2 = new Integer(tx.getGuarantee());
                if (integer2 > integer1) {
                    listElse.remove(listElse.size() - 1);
                    listElse.add(tx);
                }
            } else {
                listElse.add(tx);
            }
            if(flag2){
                return;
            }
            listElse.sort(new ComparatorUser());
            TransactionResp t = listElse.get(0);
            if (listMy.size() != 0) {
                if ((System.currentTimeMillis() - date.getTime()) >= config.getTime6()) {
                    sendTx(new String[]{listMy.get(listMy.size() - 1).getHash(), t.getHash()}, Math.max(new Integer(t.getGuarantee())*config.getStage1() / config.getStage2(), Math.max(config.getGuarantee7(), new Integer(listMy.get(listMy.size() - 1).getGuarantee()) *config.getStage1() / config.getStage2())));
                    total++;
                }
                date = new Date();
            }
            listElse.remove(t);
        }
    }

    private void handleSequencer(SequencerResp seq) throws Exception {
        sequencerResp = seq;
        list.clear();
        list2.clear();
        listMy.clear();
        listElse.clear();
        config = Config.getConfig();
        count = config.getCount();
        num = config.getNum();
        k = config.getGuarantee5();
        total = 0;
        flag = true;
        flag2 = true;
        flag3 = false;
        logger.info("received seq: " + seq.getHash());
        Thread.sleep(config.getTime1());
        sendTx(new String[]{sequencerResp.getHash()}, config.getGuarantee1());
        Thread.sleep(config.getTime2());
        flag2 = false;
    }

    private void sendTx(String[] parents, int guarantee) {
        try {
            QueryNonceResp qnr = ogSolver.queryNonce(this.ogSolver.getAccount().getAddress());
            Transaction tx = new Transaction();
            tx.setParents(parents);
            tx.setFrom(address);
            tx.setTo(null);
            tx.setNonce(qnr.getNonce() + 1);
            tx.setGuarantee(BigInteger.valueOf(guarantee));
            tx.setValue(BigInteger.valueOf(0));
            ogSolver.sendTx(tx);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (DecoderException e) {
            e.printStackTrace();
        }
    }


}
