package io.annchain.hackathon.strategy;

import lombok.Getter;
import lombok.Setter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.yaml.snakeyaml.Yaml;
// import java.io.File;

/**
 * @ClassName: Config
 * @Description:
 * @Author: 刘敬
 * @Date: 2019/9/20 14:55
 **/
@Getter
@Setter
public class Config {
    private int guarantee1;
    private int guarantee2;
    private int guarantee3;
    private int guarantee4;
    private int guarantee5;
    private int guarantee6;
    private int guarantee7;
    private int time1;
    private int time2;
    private int time3;
    private int time4;
    private int time5;
    private int time6;
    private int count;
    private int num;
    private int max;
    private int stage1;
    private int stage2;
    private int stage3;
    public static Config getConfig(){
        Yaml yaml = new Yaml();
        File file = new File(System.getProperty("user.dir")+"/config.yaml");
        try {
            return yaml.loadAs(new FileInputStream(file), Config.class);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;

    }
}
