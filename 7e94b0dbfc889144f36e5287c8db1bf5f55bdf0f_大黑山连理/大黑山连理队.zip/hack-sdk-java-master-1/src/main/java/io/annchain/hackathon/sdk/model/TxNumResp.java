package io.annchain.hackathon.sdk.model;

import lombok.Data;

@Data
public class TxNumResp {
    int data;
    String err;
}
