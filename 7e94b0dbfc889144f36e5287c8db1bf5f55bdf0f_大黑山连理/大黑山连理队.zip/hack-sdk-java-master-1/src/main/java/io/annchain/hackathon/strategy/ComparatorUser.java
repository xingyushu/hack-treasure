package io.annchain.hackathon.strategy;

import io.annchain.hackathon.sdk.model.Transaction;
import io.annchain.hackathon.sdk.model.TransactionResp;

import java.util.Comparator;

/**
 * @ClassName: ComparatorUser
 * @Description:
 * @Author: 刘敬
 * @Date: 2019/9/20 12:02
 **/
public class ComparatorUser implements Comparator {

    @Override
    public int compare(Object arg0, Object arg1) {
        TransactionResp tx1 = (TransactionResp) arg0;
        TransactionResp tx2 = (TransactionResp) arg1;
        Integer integer1=Integer.parseInt(tx1.getGuarantee());
        Integer integer2=Integer.parseInt(tx2.getGuarantee());
        return integer2.compareTo(integer1);
    }

}