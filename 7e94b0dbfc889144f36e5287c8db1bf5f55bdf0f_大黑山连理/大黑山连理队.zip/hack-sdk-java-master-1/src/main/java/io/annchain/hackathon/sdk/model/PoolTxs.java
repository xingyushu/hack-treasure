package io.annchain.hackathon.sdk.model;

import lombok.Data;

@Data
public class PoolTxs {
    SequencerResp sequencer;
    TransactionResp[] transactions;
}
