package io.annchain.hackathon.sdk.model;

import lombok.Data;

@Data
public class Txi {
    int type;
    Object data;
}
