package io.annchain.hackathon.strategy;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import io.annchain.hackathon.sdk.OgSolver;
import io.annchain.hackathon.sdk.model.*;
import org.apache.commons.codec.DecoderException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;

import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@SpringBootApplication(scanBasePackages = "io.annchain.hackathon")
public class HackathonApplication implements CommandLineRunner {

    private static Logger logger = LoggerFactory.getLogger(HackathonApplication.class);
    private static final int TXTYPE_SEQUENCER = 1;
    private static final int TXTYPE_TX = 0;
    private static final String address = "7e94b0dbfc889144f36e5287c8db1bf5f55bdf0f";
    private static final String addressHex = "0x7e94b0dbfc889144f36e5287c8db1bf5f55bdf0f";
    private static int guarantee = 100;
    private static List<TransactionResp> list = new ArrayList<TransactionResp>();
    private static List<TransactionResp> list2 = new ArrayList<TransactionResp>();
    private static List<TransactionResp> listMy = new ArrayList<TransactionResp>();
    private static List<TransactionResp> listElse = new ArrayList<TransactionResp>();
    private static SequencerResp sequencerResp = null;
    private static boolean flag = false;
    private static boolean flag2 = false;
    private static Config config=Config.getConfig();
    @Autowired
    OgSolver ogSolver;

    public static void main(String[] args) {
        SpringApplication.run(HackathonApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        ogSolver.queryTxsByAddress(address);
    }

    @KafkaListener(topics = "${app.topic}", groupId = "${api.token}")
    public void listen(@Payload String json) throws Exception {
        logger.info(json);
        JSONObject obj = JSON.parseObject(json);
        switch (obj.getIntValue("type")) {
            case TXTYPE_SEQUENCER:
                SequencerResp seq = obj.getObject("data", SequencerResp.class);
                handleSequencer(seq);
                break;
            case TXTYPE_TX:
                TransactionResp tx = obj.getObject("data", TransactionResp.class);
                handleTx(tx);
                break;
            default:
                break;
        }

    }

    private void handleTx(TransactionResp tx) {
        logger.info("received tx: " + tx.getHash());
        list.add(tx);
        if (tx.getFrom().equals(addressHex)) {
            listMy.add(tx);
        } else {
            listElse.add(tx);
            if(flag){
                sendTx(new String[]{listMy.get(listMy.size() - 1).getHash(), listElse.get(listElse.size() - 1).getHash()}, config.getGuarantee5());
            }
            String[] parents = tx.getParents();
            for (String str : parents) {
                if (str.equals(sequencerResp.getHash())) {
                    list2.add(tx);
                    break;
                }
            }
        }
    }

    private void handleSequencer(SequencerResp seq) throws Exception {
        sequencerResp = seq;
        list.clear();
        list2.clear();
        listMy.clear();
        listElse.clear();
        flag = false;
        logger.info("received seq: " + seq.getHash());
        // new Thread() {
        //     @Override
        //     public void run() {
        //         try {
        //             Thread.sleep(config.getTime5());
        //             for (TransactionResp transactionResp : list2) {
        //                 sendTx(new String[]{seq.getHash(), transactionResp.getHash()}, config.getGuarantee5());
        //             }
        //         } catch (Exception e) {
        //         }
        //     }
        // }.start();
        new Thread() {
            @Override
            public void run() {
                try {
                    Thread.sleep(config.getTime3());
                    sendTx(new String[]{listMy.get(listMy.size() - 1).getHash(), listElse.get(listElse.size() - 1).getHash()}, config.getGuarantee3());
                    Thread.sleep(config.getTime4());
                    sendTx(new String[]{listMy.get(listMy.size() - 1).getHash(), listElse.get(listElse.size() - 1).getHash()}, config.getGuarantee4());
                } catch (Exception e) {
                }
            }
        }.start();
        new Thread() {
            @Override
            public void run() {
                try {
                    Thread.sleep(config.getTime1());
                    // sendTx(new String[]{list.get(list.size()-1).getHash()}, 300);
                    flag2 = true;
                    list2.sort(new ComparatorUser());
                    if (list2.size() == 0) {
                        sendTx(new String[]{sequencerResp.getHash()}, guarantee);
                    } else {
                        sendTx(new String[]{sequencerResp.getHash(), list2.get(0).getHash()}, config.getGuarantee1());
                    }
                    flag = true;
                    Thread.sleep(config.getTime2());
                    sendTx(new String[]{listMy.get(listMy.size() - 1).getHash(), listElse.get(listElse.size() - 1).getHash()}, config.getGuarantee2());
                } catch (Exception e) {
                }
            }
        }.start();

    }

    private void sendTx(String[] parents, int guarantee) {
        try {
            QueryNonceResp qnr = ogSolver.queryNonce(this.ogSolver.getAccount().getAddress());
            Transaction tx = new Transaction();
            tx.setParents(parents);
            tx.setFrom(address);
            tx.setTo(null);
            tx.setNonce(qnr.getNonce() + 1);
            tx.setGuarantee(BigInteger.valueOf(guarantee));
            tx.setValue(BigInteger.valueOf(0));
            ogSolver.sendTx(tx);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (DecoderException e) {
            e.printStackTrace();
        }
    }


}
