package io.annchain.hackathon.sdk.model;

import lombok.Data;

@Data
public class QueryNextSeqRespData {
    long height;
    long time_left;
}
