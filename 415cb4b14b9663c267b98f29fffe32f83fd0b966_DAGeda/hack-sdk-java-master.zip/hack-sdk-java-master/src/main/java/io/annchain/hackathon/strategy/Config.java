package io.annchain.hackathon.strategy;

import lombok.Getter;
import lombok.Setter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.yaml.snakeyaml.Yaml;
// import java.io.File;

/**
 * @ClassName: Config
 * @Description:
 * @Author: 刘敬
 * @Date: 2019/9/20 14:55
 **/
@Getter
@Setter
public class Config {
    private int guarantee1;
    private int guarantee2;
    private int guarantee3;
    private int guarantee4;
    private int guarantee5;
    private int time1;
    private int time2;
    private int time3;
    private int time4;
    private int time5;
    private int time6;

    public static Config getConfig(){
        Yaml yaml = new Yaml();
        File file = new File(System.getProperty("user.dir")+"/config.yaml");
        try {
            return yaml.loadAs(new FileInputStream(file), Config.class);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;

    }

    public int getGuarantee1() {
        return guarantee1;
    }

    public void setGuarantee1(int guarantee1) {
        this.guarantee1 = guarantee1;
    }

    public int getGuarantee2() {
        return guarantee2;
    }

    public void setGuarantee2(int guarantee2) {
        this.guarantee2 = guarantee2;
    }

    public int getGuarantee3() {
        return guarantee3;
    }

    public void setGuarantee3(int guarantee3) {
        this.guarantee3 = guarantee3;
    }

    public int getGuarantee4() {
        return guarantee4;
    }

    public void setGuarantee4(int guarantee4) {
        this.guarantee4 = guarantee4;
    }

    public int getGuarantee5() {
        return guarantee5;
    }

    public void setGuarantee5(int guarantee5) {
        this.guarantee5 = guarantee5;
    }

    public int getTime1() {
        return time1;
    }

    public void setTime1(int time1) {
        this.time1 = time1;
    }

    public int getTime2() {
        return time2;
    }

    public void setTime2(int time2) {
        this.time2 = time2;
    }

    public int getTime3() {
        return time3;
    }

    public void setTime3(int time3) {
        this.time3 = time3;
    }

    public int getTime4() {
        return time4;
    }

    public void setTime4(int time4) {
        this.time4 = time4;
    }

    public int getTime5() {
        return time5;
    }

    public void setTime5(int time5) {
        this.time5 = time5;
    }

    public int getTime6() {
        return time6;
    }

    public void setTime6(int time6) {
        this.time6 = time6;
    }
}
