package io.annchain.hackathon.strategy;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import io.annchain.hackathon.sdk.OgSolver;
import io.annchain.hackathon.sdk.model.*;
import org.apache.commons.codec.DecoderException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;

import java.io.IOException;

import java.math.BigInteger;
import java.util.*;

@SpringBootApplication(scanBasePackages = "io.annchain.hackathon")
public class HackathonApplication implements CommandLineRunner {

    private static Logger logger = LoggerFactory.getLogger(HackathonApplication.class);
    private static final int TXTYPE_SEQUENCER = 1;
    private static final int TXTYPE_TX = 0;
    private static final String address = "415cb4b14b9663c267b98f29fffe32f83fd0b966";
    private static final String addressHex = "0x415cb4b14b9663c267b98f29fffe32f83fd0b966";
    private static int guarantee = 100;
    private static List<TransactionResp> list = new ArrayList<TransactionResp>();
    private static List<TransactionResp> list2 = new ArrayList<TransactionResp>();
    private static List<TransactionResp> listMy = new ArrayList<TransactionResp>();
    private static List<TransactionResp> listElse = new ArrayList<TransactionResp>();
    private static SequencerResp sequencerResp = null;
    private static boolean flag = false;
    private boolean canStart = false;
    private long preSeqTime;
    private long preTime;
    private long preNonce;
    private int sendCnt=0;
    private int unSendCnt=0;
    private int followedG;
    private int followedI;
    private String preMy="";
    private Set<String> vis=new HashSet<>();


    @Autowired
    OgSolver ogSolver;

    public static void main(String[] args) {
        SpringApplication.run(HackathonApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        ogSolver.queryTxsByAddress(address);
    }

    @KafkaListener(topics = "${app.topic}", groupId = "${api.token}")
    public void listen(@Payload String json) throws Exception {
//        logger.info(json);
        JSONObject obj = JSON.parseObject(json);
        switch (obj.getIntValue("type")) {
            case TXTYPE_SEQUENCER:
                SequencerResp seq = obj.getObject("data", SequencerResp.class);
                handleSequencer(seq);
                break;
            case TXTYPE_TX:
                if (!canStart) break;
                TransactionResp tx = obj.getObject("data", TransactionResp.class);
                handleTx(tx);
                break;
            default:
                break;
        }

    }

    private void handleTx(TransactionResp tx) {
        if (!canStart) return;
        if (sendCnt+unSendCnt>=100) return;

//        logger.info("received tx: " + tx.getHash());

        if (tx.getFrom().equals(addressHex)) {
            listMy.add(tx);
        } else {
            int firstGurantee=2000;
            listElse.add(tx);
            if (System.currentTimeMillis()-preSeqTime<1*1000){
                return;
            }
            if (System.currentTimeMillis()-preTime<14){
                return;
            }


            preTime=System.currentTimeMillis();

            for (int i=0;i<listElse.size();i++){
                String[] fathers=listElse.get(i).getParents();
                for (int j=0;j<fathers.length;j++){
                    if (fathers[j].equals(sequencerResp.getHash())){
                        if (Integer.valueOf(listElse.get(i).getGuarantee())>firstGurantee){
                            firstGurantee=Integer.valueOf(listElse.get(i).getGuarantee());
                        }
                    }
                }
            }

            if (listMy.size() == 0){
                if (firstGurantee>4000) firstGurantee=4000;
                followedI = -1;

                for (int i=0;i<listElse.size();i++) {
                    if (vis.contains(listElse.get(i).getHash())) {
                        continue;
                    }else{
                        followedI=i;
                        break;
                    }
                }
                if (followedI==-1) return;

                for (int i=0;i<listElse.size();i++){
                    if (vis.contains(listElse.get(i).getHash())){
                        continue;
                    }
                    if (Integer.valueOf(listElse.get(i).getGuarantee())>Integer.valueOf(listElse.get(followedI).getGuarantee())){
                        followedI=i;
                    }
                }

                sendTx(new String[]{sequencerResp.getHash(), listElse.get(followedI).getHash()}, firstGurantee-1);
                try {
                    long nNonce = ogSolver.queryNonce(address).getNonce();
                    if (nNonce != preNonce) {
                        preNonce = nNonce;
                        sendCnt++;
                        vis.add(listElse.get(followedI).getHash());
                    }else {
                        unSendCnt++;
                    }
                }catch (IOException e){
                    e.printStackTrace();
                }

            }else {
                Random rd=new Random();
                followedI = -1;

                for (int i=0;i<listElse.size();i++) {
                    if (vis.contains(listElse.get(i).getHash())) {
                        continue;
                    }else{
                        followedI=i;
                        break;
                    }
                }
                if (followedI==-1) return;

                for (int i=0;i<listElse.size();i++){
                    if (vis.contains(listElse.get(i).getHash())){
                        continue;
                    }
                    if (Integer.valueOf(listElse.get(i).getGuarantee())>Integer.valueOf(listElse.get(followedI).getGuarantee())){
                        followedI=i;
                    }
                }

                if (preMy.equals(listMy.get(listMy.size() - 1).getHash())) return;
                int tempG=(Integer.valueOf(listElse.get(followedI).getGuarantee()) + Integer.valueOf(listMy.get(listMy.size() - 1).getGuarantee()) )/3;
                if (tempG<100) tempG=100;

                sendTx(new String[]{listMy.get(listMy.size() - 1).getHash(),
                        listElse.get(followedI).getHash()},
                        tempG >3000? 1200:tempG
                );
                preMy=listMy.get(listMy.size() - 1).getHash();

                try {
                    long nNonce = ogSolver.queryNonce(address).getNonce();
                    if (nNonce != preNonce) {
                        preNonce = nNonce;
                        sendCnt++;
                        followedG-=200;
                        vis.add(listElse.get(followedI).getHash());
                        if (followedG<200) {
                            followedG=200+rd.nextInt()%50;
                        }
                        sendCnt++;
                    }else{
                        unSendCnt++;
                    }
                }catch (IOException e){
                    e.printStackTrace();
                }

            }
        }
    }

    private void handleSequencer(SequencerResp seq) throws Exception {
        canStart=true;
        sequencerResp = seq;
        list.clear();
        list2.clear();
        listMy.clear();
        listElse.clear();
        flag = false;
        preSeqTime=System.currentTimeMillis();
        preTime=preSeqTime;
        System.out.println(sendCnt);
        System.out.println(unSendCnt);
        sendCnt=0;
        followedG=1800;
        followedI=0;
        unSendCnt=0;
        preMy="";
        preNonce=ogSolver.queryNonce(address).getNonce();
        vis.clear();
    }

    private void sendTx(String[] parents, int guarantee) {
        try {
            QueryNonceResp qnr = ogSolver.queryNonce(this.ogSolver.getAccount().getAddress());
            Transaction tx = new Transaction();
            tx.setParents(parents);
            tx.setFrom(address);
            tx.setTo(null);
            tx.setNonce(qnr.getNonce() + 1);
            tx.setGuarantee(BigInteger.valueOf(guarantee));
            tx.setValue(BigInteger.valueOf(0));
            ogSolver.sendTx(tx);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (DecoderException e) {
            e.printStackTrace();
        }
    }


}
