package io.annchain.hackathon.sdk.model;

import lombok.Data;

@Data
public class QueryNextSeqResp {
    QueryNextSeqRespData data;
    String err;
}
